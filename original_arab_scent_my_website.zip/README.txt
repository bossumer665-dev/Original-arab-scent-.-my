ORIGINAL ARAB SCENT MY — WEBSITE STARTER

Files
- index.html: responsive storefront with product filters, cart drawer, checkout form, and WhatsApp order handoff.

Preview
1. Open index.html in a browser, or upload it and the rest of this folder to a static host.
2. The product names and prices are editable in the products array near the bottom of index.html.

IMPORTANT BEFORE LAUNCH
- Change WHATSAPP_NUMBER in the script to your real WhatsApp number in international digits-only format.
- Replace sample products, pricing, descriptions, reviews, and photos with accurate store content. Product photos currently load from Unsplash and require internet access.
- Checkout is a demo/order enquiry flow. No money is collected. For live online payments, connect a provider such as ToyyibPay, Billplz, Stripe, or another supported Malaysian payment gateway through a secure server/backend. Never put secret API keys in browser HTML.
- Add real shipping, returns, privacy, and terms policies before accepting orders.
- The newsletter form is a visual demo and is not connected to an email platform.

This is a starter storefront, not a deployed public website.
